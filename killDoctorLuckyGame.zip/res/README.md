# Kill Doctor Lucky Milestone1

author: Zhixiao Wu<br>
mail: wu.zhixia@northeastern.edu<br><br>

example runs:<br><br>
res/example_runs/example_run1 : Valid, created gameWorldMap.png (res/gameWorldMap.png). <br>
The target walked through all 20 spaces started from 0, and displaied information about each specified space such as index, name, items inside and neighbors.<br>
The successful output of neighbors shows that neighbors are successfully found.<br><br>
res/example_runs/example_tun2 : Wrong file path, can't find according file, showing error in the console<br><br>
res/example_runs/example_tun3 : Wrong file content, one parameter is negative, showing error in the console. 
